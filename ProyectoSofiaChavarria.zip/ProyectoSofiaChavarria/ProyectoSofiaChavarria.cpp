#include <SFML/Graphics.hpp>
#include <iostream>
#include "Game.h"

int main()
{
    Game game = Game();
    game.run();
    return 0;
}
